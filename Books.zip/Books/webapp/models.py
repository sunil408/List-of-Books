from django.db import models
from django.urls import reverse
# Create your models here.

class Books(models.Model):
    Book_Name=models.CharField(max_length=50)
    Author_Name=models.CharField(max_length=20)
    Description=models.TextField()

    def get_absolute_url(self):
        return reverse('retrive', kwargs={"id": self.id})


