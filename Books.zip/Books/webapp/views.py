from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import bookforms
from .models import Books
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required

# Create your views here.
@ login_required()
def home(request):
    lst = Books.objects.all()
    return render(request, 'home.html', {'lst': lst})


def create(request):
    form = bookforms(request.POST or None, request.FILES or None)
    if form.is_valid():
        instance = form.save()
        instance.save()
        return HttpResponseRedirect('/')
    context = {'form': form}
    return render(request, "create.html", context)

def read(request,id=None):
    instance = get_object_or_404(Books,id=id)
    context = {'instance': instance}
    return render(request,"retrive.html",context)

def update(request,id=None):
    instance = get_object_or_404(Books, id=id)
    form = bookforms(request.POST or None, request.FILES or None, instance=instance)
    if form.is_valid():
        instance = form.save()
        instance.save()
        return HttpResponseRedirect(instance.get_absolute_url())
    context = {'instance': instance, 'form': form}
    return render(request, "update.html", context)

def delete(request,id=None):
	instance =get_object_or_404(Books,id=id)
	instance.delete()
	return render(request,"delete.html")

def logout(request):
    return render(request,'logout.html')
